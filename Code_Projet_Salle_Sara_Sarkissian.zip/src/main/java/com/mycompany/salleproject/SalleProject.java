/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.salleproject;

/**
 *
 * @author sarkissian
 */
public class SalleProject {

    public static void main(String[] args) {
        
        MyFrame myFrame = new MyFrame("Ma Salle", 400, 800);
        
        
    }
}
